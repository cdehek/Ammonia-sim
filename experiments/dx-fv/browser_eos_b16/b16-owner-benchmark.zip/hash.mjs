// B16 diagnostic evidence only. Incremental SHA-256 of length-delimited exact JSON.
import {exact} from './assets/values.mjs';
const K=new Uint32Array([0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
const rr=(x,n)=>(x>>>n)|(x<<(32-n));
export class SHA256 {
 constructor(){this.h=new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);this.b=new Uint8Array(64);this.n=0;this.total=0;this.w=new Uint32Array(64);}
 block(){const w=this.w,d=new DataView(this.b.buffer);for(let i=0;i<16;i++)w[i]=d.getUint32(i*4);for(let i=16;i<64;i++){const x=w[i-15],y=w[i-2];w[i]=(w[i-16]+(rr(x,7)^rr(x,18)^(x>>>3))+w[i-7]+(rr(y,17)^rr(y,19)^(y>>>10)))>>>0;}
  let [a,b,c,d0,e,f,g,h]=this.h;for(let i=0;i<64;i++){const t1=(h+(rr(e,6)^rr(e,11)^rr(e,25))+((e&f)^(~e&g))+K[i]+w[i])>>>0,t2=((rr(a,2)^rr(a,13)^rr(a,22))+((a&b)^(a&c)^(b&c)))>>>0;h=g;g=f;f=e;e=(d0+t1)>>>0;d0=c;c=b;b=a;a=(t1+t2)>>>0;}
  [a,b,c,d0,e,f,g,h].forEach((v,i)=>this.h[i]=(this.h[i]+v)>>>0);
 }
 update(raw){if(typeof raw==='string')raw=new TextEncoder().encode(raw);this.total+=raw.length;for(let i=0;i<raw.length;){const take=Math.min(64-this.n,raw.length-i);this.b.set(raw.subarray(i,i+take),this.n);this.n+=take;i+=take;if(this.n===64){this.block();this.n=0;}}return this;}
 hex(){const bits=this.total*8;this.update(new Uint8Array([128]));while(this.n!==56)this.update(new Uint8Array([0]));const tail=new Uint8Array(8),d=new DataView(tail.buffer);d.setUint32(0,Math.floor(bits/4294967296));d.setUint32(4,bits>>>0);this.update(tail);return [...this.h].map(v=>v.toString(16).padStart(8,'0')).join('');}
}
export class Stream {
 constructor(){this.hash=new SHA256();this.count=0;this.bytes=0;}
 add(value){const text=JSON.stringify(exact(value)),bytes=new TextEncoder().encode(text);this.hash.update(String(bytes.length)+':').update(bytes);this.count++;this.bytes+=bytes.length;}
 finish(){return {count:this.count,bytes:this.bytes,sha256:this.hash.hex()};}
}
export function hash(value){const s=new Stream();s.add(value);return s.finish().sha256;}
